#include "config.h"
#define NARROWCHAR
#include "tokenizer.c"
