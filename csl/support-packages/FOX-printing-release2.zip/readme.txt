This class allows multiplatform device independant printing. 
Under unix everything is redirected to the postscript driver, and under
Windows it uses either the postscript driver or the system spool.
You can select the destination with a FXPrintDialog, as this class
uses an FXPrinter to do its setup.


FEATURES:

1. Arbitrary units. You can select diferent drawing units for both 
the vertical and horizontal axis. Default is 72 pixels per inch.

2. Integrated font management. Ask it for a size 10 font, and the class
will do all necessary conversions to ensure the same results on devices
with different resolutions. Remember to access the font via the
printing class.



QUICK SAMPLE:
- For a complete sample look at sample.cpp


void print_something(void) {
FXPrinter printer;
FXDCNativePrinter prt(getApp());
FXFont *font;
char string[]="Hi there!";

    /* Printer selection */
    FXPrintDialog dlg(this,"");
    dlg.execute();
    dlg.getPrinter( printer );   
    
    /* Begin printing */
    prt.beginPrint(printer);
    
    /* Create a font with point size 12 */
    font = prt.fntGenerateFont("helvetica", 12);
    font->create();
    
    prt.beginPage(1);    
    prt.setTextFont( font );
    
    /* Write text one inch from the border */
    prt.drawText(72,72, string, strlen(string) );
    
    prt.endPage();
    prt.endPrint();
}


