#!/bin/bash
# simple wrapper, libtool is called as /bin/bash ../../libtool
exec ${0}-cache.pl "$@"
