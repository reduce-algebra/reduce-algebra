#ifndef FXCLIENTSOCKET_H
#define FXCLIENTSOCKET_H

#include <FXSocket.h>

class FXClientSocket: public FXSocket {
  FXDECLARE(FXClientSocket);

private:
  FXString ServerAddress;
  FXString ServerName;
  FXint ServerPort;
  struct hostent *hostinfo;
protected:
  FXClientSocket() {};
public:
  FXClientSocket(FXApp *app, FXObject *tgt, FXSelector sel);
  ~FXClientSocket() {};
  virtual void create();

  FXint setServerAddress(const FXString &ServerAddress);
  FXint setServerName(const FXString &ServerName);
  FXint setServerPort(FXint ServerPort);
  FXString getServerAddress() const { return ServerAddress; };
  FXString getServerName() const { return ServerName; };
  FXint getServerPort() const { return ServerPort; };
  long connect();
};

#endif
