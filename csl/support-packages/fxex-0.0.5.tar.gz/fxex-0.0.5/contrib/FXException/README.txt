This is a modified implementation of exception handling...

It tries to emulate the exception mechanism using setjump/longjump, for the cases when
the programmer wants to use try-catch.

It is meant to do this without the runtime performace degradation normally assocaiated
with normal exception mechanisms.

