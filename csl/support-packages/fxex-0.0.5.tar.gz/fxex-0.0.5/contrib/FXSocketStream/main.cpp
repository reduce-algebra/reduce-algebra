#include <fox/fx.h>
#include <signal.h>
#include "mainwindow.h"

int main(int argc,char *argv[]){

  FXApp app("TestApp",FXString::null);
  app.init(argc,argv);
  mainwindow window(&app);

  app.addSignal(SIGINT,&window,mainwindow::ID_QUIT);
  app.create();

  return app.run();
  }
