/************************************-*- mode: c++; tab-width: 2 -*-
 * 
 * NAME:
 *    main
 *  AUTHOR:
 *    Daniel Gehriger
 * 
 * Copyright (c) 2000 by Daniel Gehriger.  All Rights Reserved
 * 
 * PUPROSE:
 *    Main Application Header
 * 
 * 
\******************************************************************/
#ifndef MAIN_H
#define MAIN_H

#include <fx.h>

/*
** COM Support
*/
#ifdef WIN32
#import <someocx.ocx> no_namespace
class CEventSink;
class CContainer;

void                    connectEvents();
void                    disconnectEvents();
IConnectionPoint*       getConnectionPoint(REFIID riid);

extern CEventSink*      g_pEvent;
extern CContainer*      g_pContainer;
extern DWORD            g_dwCookie;    // unique id for event wiring
extern _DSomeocxPtr   	g_pSomeocx;

#endif

#endif /* MAIN_H */
