// make a binary log file, containing dump data

#include "fxex.h"

int main(int argc,char *argv[]){
  FXApp a("makedummylog","FoxExTest");
  a.init(argc,argv,FALSE);
  FXBinaryLogger log("log.binlog");
  log.log(1);
  log.log(2);
  log.log(3);
  return 0;
  }

