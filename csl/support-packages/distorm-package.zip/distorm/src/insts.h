/*
insts.h

Copyright (C) 2003-2006 Gil Dabah, http://ragestorm.net/distorm/
This library is licensed under the BSD license. See the file COPYING.
*/


#ifndef ___INSTS_H__
#define ___INSTS_H__

#include "instructions.h"

extern _InstNode Instructions[256];

// See instructions.cpp for more info.

#endif // ___INSTS_H__
